import React, { useEffect } from "react";
import "./App.css";
import Header from "./Header.js";
import Home from "./Home.js";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Checkout from "./Checkout";
import Login from "./Login";
import Orders from "./Orders"
import { auth } from "./firebase";
import { useStateValue } from "./StateProvider";
import Payment from "./Payment";
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import Tracker from "./Tracker";

const promise = loadStripe(
  "pk_test_51JmAnYSBIe85uRpkIXPz8kt0yO4t0dzOrQw17GzUr1nrN3rciz2QWCbLAGNhFTJEvo2zfCMAve6z58vn1mwlyGC700DXzHl983"
);
//sk_test_51JmAnYSBIe85uRpk0wLjbEd6xvq2qPiyNv9qIFvURWDPmsCt54wlw1Yr6wgyUtxtUA08eB8LFD5s1Ptn6nVcu3Vr00cHI4Vaap  secret key
function App() {
  const [{}, dispatch] = useStateValue();

  useEffect(() => {
    // will only run once when the app component loads...

    auth.onAuthStateChanged((authUser) => {
      console.log("THE USER IS >>> ", authUser);

      if (authUser) {
        // the user just logged in / the user was logged in

        dispatch({
          type: "SET_USER",
          user: authUser,
        });
      } 
      else {
        // the user is logged out
        dispatch({
          type: "SET_USER",
          user: null,
        });
      }
    });
  }, []);

  return (
    //BEM
    <Router>
      <div className="App">
        <Switch>

          <Route path="/orders">
            <Header />
            <Orders />
          </Route>

          <Route path="/tracker">
            <Header />
            <Tracker />
          </Route>

          <Route path="/login">
            <Login />
          </Route>

          <Route path="/checkout">
            <Header />
            <Checkout />
          </Route>

          <Route path="/payment">
            <Header />
            <Elements stripe={promise}>
              <Payment />
            </Elements>
          </Route>

          <Route path="/">
            <Header />
            <arouselContainer/>
            <Home />
          </Route>

        </Switch>
      </div>
    </Router>
  );
}

export default App;
